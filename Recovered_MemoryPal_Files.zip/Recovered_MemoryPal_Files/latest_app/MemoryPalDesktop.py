import json
import random
import re
import shutil
import sys
import tkinter as tk
import ctypes
from collections import Counter
from dataclasses import asdict, dataclass, field
from datetime import date, datetime, timedelta
from difflib import SequenceMatcher
from pathlib import Path
from tkinter import filedialog, messagebox, ttk
from uuid import uuid4


APP_NAME = "MemoryPal"
DATA_DIR = Path.home() / "MemoryPalData"
DATA_FILE = DATA_DIR / "memorypal-data.json"
ATTACHMENT_DIR = DATA_DIR / "attachments"
BASE_DPI = 96
BASE_WINDOW = (1420, 900)
BASE_MIN_WINDOW = (1080, 720)

COLORS = {
    "bg": "#f6f7fb",
    "surface": "#ffffff",
    "alt": "#eef5ff",
    "ink": "#111827",
    "muted": "#6b7280",
    "line": "#e5e7ef",
    "primary": "#007aff",
    "primary_dark": "#0066d6",
    "green": "#34c759",
    "orange": "#ff9500",
    "pink": "#ff2d55",
    "violet": "#af52de",
    "cyan": "#32ade6",
    "rail": "#111827",
    "rail_hover": "#1f2937",
    "white": "#ffffff",
    "danger": "#ff3b30",
}


def clamp(value, low, high):
    return max(low, min(high, value))


def enable_dpi_awareness():
    if not sys.platform.startswith("win"):
        return
    try:
        ctypes.windll.shcore.SetProcessDpiAwareness(2)
    except (AttributeError, OSError):
        try:
            ctypes.windll.user32.SetProcessDPIAware()
        except (AttributeError, OSError):
            pass


def uid():
    return str(uuid4())


def today_iso():
    return date.today().isoformat()


def add_days(days):
    return (date.today() + timedelta(days=days)).isoformat()


def now_label():
    return datetime.now().strftime("%Y-%m-%d %H:%M")


def normalize_space(value):
    return re.sub(r"\s+", " ", value or "").strip()


def split_study_bits(raw):
    raw = (raw or "").replace("\\n", "\n").replace("/n", "\n")
    raw = re.sub(r"\s+(?=\d+[.)]\s+)", "\n", raw)
    raw = re.sub(r"\s*[|;]\s*", "\n", raw)
    lines = [re.sub(r"^[-*\d.)\s]+", "", line).strip() for line in raw.splitlines()]
    lines = [line for line in lines if line]
    if len(lines) >= 2:
        return lines
    sentences = [part.strip() for part in re.split(r"[.!?]+", raw) if part.strip()]
    if len(sentences) > 1:
        return sentences
    comma_bits = [part.strip() for part in raw.split(",") if part.strip()]
    return comma_bits if len(comma_bits) > 1 else ([raw.strip()] if raw.strip() else [])


STOP_WORDS = {
    "the", "and", "for", "with", "into", "that", "this", "what", "should",
    "remember", "image", "audio", "video", "cue", "about", "from", "your",
    "their", "there", "then", "than", "when", "where", "which", "while",
    "because", "have", "has", "had", "are", "was", "were", "will", "would",
    "could", "also", "just", "like", "make", "made",
}


def text_tokens(value):
    tokens = []
    for token in re.findall(r"[A-Za-z0-9][A-Za-z0-9'-]{2,}", value or ""):
        token = token.lower()
        if token in STOP_WORDS:
            continue
        for suffix in ("ingly", "edly", "ing", "ed", "es", "s"):
            if token.endswith(suffix) and len(token) > len(suffix) + 3:
                token = token[: -len(suffix)]
                break
        tokens.append(token)
    return tokens


def answer_assessment(response, expected, context=""):
    response = normalize_space(response)
    expected_text = normalize_space(" ".join(part for part in [expected, context] if part))
    if not response:
        return {
            "score": 0,
            "quality": 1,
            "label": "Needs response",
            "bucket": "Again",
            "repetitions": 5,
            "detail": "Type an answer, transcript, caption, or media description first.",
        }

    expected_tokens = text_tokens(expected_text)
    response_tokens = text_tokens(response)
    sequence = SequenceMatcher(None, response.lower(), expected_text.lower()).ratio() if expected_text else 0
    expected_set = set(expected_tokens)
    response_set = set(response_tokens)
    coverage = len(expected_set & response_set) / max(1, len(expected_set))

    expected_counts = Counter(expected_tokens)
    response_counts = Counter(response_tokens)
    weighted_hits = sum(min(response_counts[word], expected_counts[word]) for word in expected_counts)
    weighted = weighted_hits / max(1, sum(expected_counts.values()))

    score = min(100, round(100 * (0.28 * sequence + 0.52 * coverage + 0.20 * weighted)))
    if score >= 82:
        quality, label, reps, bucket = 5, "Strong match", 1, "Easy"
    elif score >= 64:
        quality, label, reps, bucket = 4, "Close enough", 2, "Good"
    elif score >= 42:
        quality, label, reps, bucket = 3, "Partial match", 3, "Review"
    elif score >= 24:
        quality, label, reps, bucket = 2, "Weak match", 4, "Again"
    else:
        quality, label, reps, bucket = 1, "Missed context", 5, "Again"

    missing = [word for word, _count in expected_counts.most_common(6) if word not in response_set]
    detail = "Missing key cues: " + ", ".join(missing[:4]) if missing else "Main cues are covered."
    return {"score": score, "quality": quality, "label": label, "bucket": bucket, "repetitions": reps, "detail": detail}


@dataclass
class Card:
    id: str = field(default_factory=uid)
    deck: str = "General"
    front: str = ""
    back: str = ""
    pathway: str = ""
    association: str = ""
    image: str = ""
    audio: str = ""
    video: str = ""
    next_review: str = field(default_factory=today_iso)
    interval: int = 0
    repetitions: int = 0
    ease: float = 2.5
    lapses: int = 0

    @classmethod
    def from_dict(cls, raw):
        values = {field_name: raw.get(field_name) for field_name in cls.__dataclass_fields__}
        values["id"] = raw.get("id", uid())
        values["next_review"] = raw.get("next_review", raw.get("nextReview", today_iso()))
        values["interval"] = int(raw.get("interval", 0))
        values["repetitions"] = int(raw.get("repetitions", 0))
        values["ease"] = float(raw.get("ease", 2.5))
        values["lapses"] = int(raw.get("lapses", 0))
        return cls(**values)


@dataclass
class Capture:
    id: str = field(default_factory=uid)
    title: str = "Captured memory material"
    notes: str = ""
    chunks: list = field(default_factory=list)
    image: str = ""
    audio: str = ""
    video: str = ""
    created_at: str = field(default_factory=now_label)

    @classmethod
    def from_dict(cls, raw):
        notes = raw.get("notes", "")
        chunks = raw.get("chunks") or split_study_bits(notes)
        return cls(
            id=raw.get("id", uid()),
            title=raw.get("title", "Captured memory material"),
            notes=notes,
            chunks=chunks,
            image=raw.get("image", ""),
            audio=raw.get("audio", ""),
            video=raw.get("video", ""),
            created_at=raw.get("created_at", raw.get("createdAt", now_label())),
        )


def sample_cards():
    return [
        Card(
            deck="Memory Techniques",
            front="What is spaced repetition?",
            back="Reviewing information at increasing intervals so recall strengthens over time.",
            pathway="Dashboard > Review > due cards",
            association="The space between reviews grows like stepping stones.",
        ),
        Card(
            deck="Memory Techniques",
            front="What is retrieval practice?",
            back="Trying to recall the answer before rereading or revealing it.",
            pathway="Quiz > Self Check",
            association="Pull the memory out instead of looking it up first.",
        ),
    ]


class MemoryStore:
    def __init__(self):
        self.cards = []
        self.captures = []
        self.practiced = 0
        self.load()

    def load(self):
        DATA_DIR.mkdir(parents=True, exist_ok=True)
        ATTACHMENT_DIR.mkdir(parents=True, exist_ok=True)
        if not DATA_FILE.exists():
            self.cards = sample_cards()
            self.save()
            return
        try:
            raw = json.loads(DATA_FILE.read_text(encoding="utf-8"))
            self.cards = [Card.from_dict(item) for item in raw.get("cards", [])]
            self.captures = [Capture.from_dict(item) for item in raw.get("captures", [])]
            self.practiced = int(raw.get("practiced", 0))
        except (OSError, json.JSONDecodeError, ValueError):
            self.cards = sample_cards()
            self.captures = []
            self.practiced = 0

    def save(self):
        DATA_DIR.mkdir(parents=True, exist_ok=True)
        DATA_FILE.write_text(
            json.dumps(
                {
                    "cards": [asdict(card) for card in self.cards],
                    "captures": [asdict(capture) for capture in self.captures],
                    "practiced": self.practiced,
                },
                indent=2,
            ),
            encoding="utf-8",
        )

    def due_cards(self):
        return [card for card in self.cards if card.next_review <= today_iso()]

    def add_card(self, card):
        self.cards.insert(0, card)
        self.save()

    def add_capture(self, capture):
        self.captures.insert(0, capture)
        self.save()

    def schedule(self, card, quality):
        if quality < 3:
            card.repetitions = 0
            card.interval = 1
            card.lapses += 1
        else:
            if card.repetitions == 0:
                card.interval = 1
            elif card.repetitions == 1:
                card.interval = 3
            else:
                card.interval = max(1, round(card.interval * card.ease))
            card.repetitions += 1
        card.ease = max(1.3, card.ease + (0.1 - (5 - quality) * 0.08))
        card.next_review = add_days(card.interval)
        self.practiced += 1
        self.save()

    def reset(self):
        self.cards = sample_cards()
        self.captures = []
        self.practiced = 0
        self.save()


class ScrollFrame(ttk.Frame):
    def __init__(self, parent):
        super().__init__(parent)
        self.mouse_inside = False
        self.canvas = tk.Canvas(self, highlightthickness=0, bg=COLORS["bg"])
        self.scrollbar = ttk.Scrollbar(self, orient="vertical", command=self.canvas.yview)
        self.inner = ttk.Frame(self.canvas, style="Page.TFrame")
        self.window_id = self.canvas.create_window((0, 0), window=self.inner, anchor="nw")
        self.canvas.configure(yscrollcommand=self.scrollbar.set)
        self.canvas.pack(side="left", fill="both", expand=True)
        self.scrollbar.pack(side="right", fill="y")
        self.inner.bind("<Configure>", lambda _event: self.canvas.configure(scrollregion=self.canvas.bbox("all")))
        self.canvas.bind("<Configure>", lambda event: self.canvas.itemconfigure(self.window_id, width=event.width))
        self.canvas.bind("<Enter>", self._enter)
        self.canvas.bind("<Leave>", self._leave)
        self.inner.bind("<Enter>", self._enter)
        self.inner.bind("<Leave>", self._leave)
        self.canvas.bind_all("<MouseWheel>", self._wheel)

    def _enter(self, _event=None):
        self.mouse_inside = True

    def _leave(self, _event=None):
        self.mouse_inside = False

    def _wheel(self, event):
        if self.winfo_ismapped() and self.mouse_inside:
            self.canvas.yview_scroll(int(-event.delta / 120), "units")


class MemoryPalApp(tk.Tk):
    def __init__(self):
        super().__init__()
        self.dpi_scale, self.size_scale = self._display_scales()
        self.ui_scale = clamp(max(self.dpi_scale, self.size_scale), 0.95, 1.35)
        self.font_scale = clamp(self.size_scale, 0.96, 1.12)
        try:
            self.tk.call("tk", "scaling", clamp(self.dpi_scale * BASE_DPI / 72, 1.0, 2.4))
        except tk.TclError:
            pass
        self.store = MemoryStore()
        self.current_view = "dashboard"
        self.current_review = None
        self.quiz_cards = []
        self.quiz_round = 0
        self.quiz_score = 0
        self.quiz_mode = "self"
        self.sequence = ""
        self.pending_media = {"image": "", "audio": "", "video": ""}

        self.title(APP_NAME)
        self._set_window_size()
        self.configure(bg=COLORS["bg"])
        self._styles()
        self._shell()
        self.show_view("dashboard")

    def _display_scales(self):
        try:
            dpi = float(self.winfo_fpixels("1i"))
        except tk.TclError:
            dpi = BASE_DPI
        dpi_scale = clamp(dpi / BASE_DPI, 1.0, 1.65)
        screen_w = max(1, self.winfo_screenwidth())
        screen_h = max(1, self.winfo_screenheight())
        size_scale = clamp(min(screen_w / 1536, screen_h / 960), 0.92, 1.14)
        return dpi_scale, size_scale

    def px(self, value):
        return max(1, int(round(value * self.ui_scale)))

    def font(self, family, size):
        return (family, max(8, int(round(size * self.font_scale))))

    def pad(self, *values):
        return tuple(self.px(value) for value in values)

    def _set_window_size(self):
        screen_w = self.winfo_screenwidth()
        screen_h = self.winfo_screenheight()
        margin = self.px(96)
        width = min(self.px(BASE_WINDOW[0]), max(self.px(980), screen_w - margin))
        height = min(self.px(BASE_WINDOW[1]), max(self.px(640), screen_h - margin))
        min_width = min(self.px(BASE_MIN_WINDOW[0]), width)
        min_height = min(self.px(BASE_MIN_WINDOW[1]), height)
        self.geometry(f"{width}x{height}")
        self.minsize(min_width, min_height)

    def _styles(self):
        self.style = ttk.Style(self)
        self.style.theme_use("clam")
        self.option_add("*Font", self.font("Segoe UI", 12))
        self.style.configure("Root.TFrame", background=COLORS["bg"])
        self.style.configure("Rail.TFrame", background=COLORS["rail"])
        self.style.configure("Page.TFrame", background=COLORS["bg"])
        self.style.configure("Card.TFrame", background=COLORS["surface"], relief="flat", borderwidth=0)
        self.style.configure("AltCard.TFrame", background=COLORS["alt"], relief="flat", borderwidth=0)
        self.style.configure("TLabel", background=COLORS["bg"], foreground=COLORS["ink"], font=self.font("Segoe UI", 12))
        self.style.configure("Muted.TLabel", background=COLORS["bg"], foreground=COLORS["muted"], font=self.font("Segoe UI", 11))
        self.style.configure("Card.TLabel", background=COLORS["surface"], foreground=COLORS["ink"], font=self.font("Segoe UI", 12))
        self.style.configure("CardMuted.TLabel", background=COLORS["surface"], foreground=COLORS["muted"], font=self.font("Segoe UI", 11))
        self.style.configure("AltCard.TLabel", background=COLORS["alt"], foreground=COLORS["ink"], font=self.font("Segoe UI", 12))
        self.style.configure("AltMuted.TLabel", background=COLORS["alt"], foreground=COLORS["muted"], font=self.font("Segoe UI", 11))
        self.style.configure("Title.TLabel", background=COLORS["bg"], foreground=COLORS["ink"], font=self.font("Segoe UI Semibold", 28))
        self.style.configure("H2.TLabel", background=COLORS["surface"], foreground=COLORS["ink"], font=self.font("Segoe UI Semibold", 18))
        self.style.configure("AltH2.TLabel", background=COLORS["alt"], foreground=COLORS["ink"], font=self.font("Segoe UI Semibold", 18))
        self.style.configure("Stat.TLabel", background=COLORS["surface"], foreground=COLORS["primary"], font=self.font("Segoe UI Semibold", 34))
        self.style.configure("RailTitle.TLabel", background=COLORS["rail"], foreground=COLORS["white"], font=self.font("Segoe UI Semibold", 20))
        self.style.configure("RailText.TLabel", background=COLORS["rail"], foreground="#9ca3af", font=self.font("Segoe UI", 12))
        self.style.configure("TEntry", padding=self.px(10), fieldbackground=COLORS["white"], bordercolor=COLORS["line"])
        self.style.configure("TCombobox", padding=self.px(10), fieldbackground=COLORS["white"])
        self.style.configure("TButton", padding=self.pad(18, 12), background=COLORS["white"], foreground=COLORS["ink"], borderwidth=0, relief="flat", font=self.font("Segoe UI Semibold", 11))
        self.style.map("TButton", background=[("active", "#eef5ff")], foreground=[("active", COLORS["primary"])])
        self.style.configure("Primary.TButton", padding=self.pad(18, 12), background=COLORS["primary"], foreground=COLORS["white"], borderwidth=0, relief="flat", font=self.font("Segoe UI Semibold", 12))
        self.style.map("Primary.TButton", background=[("active", COLORS["primary_dark"])])
        self.style.configure("Danger.TButton", padding=self.pad(18, 12), background=COLORS["danger"], foreground=COLORS["white"], borderwidth=0, relief="flat", font=self.font("Segoe UI Semibold", 11))
        self.style.configure("Nav.TButton", padding=self.pad(20, 15), background=COLORS["rail"], foreground="#d7def0", anchor="w", borderwidth=0, relief="flat", font=self.font("Segoe UI", 12))
        self.style.configure("ActiveNav.TButton", padding=self.pad(20, 15), background=COLORS["primary"], foreground=COLORS["white"], anchor="w", borderwidth=0, relief="flat", font=self.font("Segoe UI Semibold", 12))

    def _shell(self):
        root = ttk.Frame(self, style="Root.TFrame")
        root.pack(fill="both", expand=True)

        self.rail = ttk.Frame(root, width=self.px(276), style="Rail.TFrame")
        self.rail.pack(side="left", fill="y")
        self.rail.pack_propagate(False)

        brand = ttk.Frame(self.rail, style="Rail.TFrame")
        brand.pack(fill="x", padx=self.px(22), pady=self.pad(30, 26))
        mark_size = self.px(54)
        mark = tk.Canvas(brand, width=mark_size, height=mark_size, bg=COLORS["rail"], highlightthickness=0)
        mark.pack(side="left", padx=(0, self.px(14)))
        mark.create_oval(self.px(5), self.px(5), self.px(49), self.px(49), fill=COLORS["primary"], outline="")
        mark.create_text(mark_size // 2, mark_size // 2, text="M", fill=COLORS["white"], font=self.font("Segoe UI Semibold", 23))
        label_box = ttk.Frame(brand, style="Rail.TFrame")
        label_box.pack(side="left")
        ttk.Label(label_box, text="MemoryPal", style="RailTitle.TLabel").pack(anchor="w")
        ttk.Label(label_box, text="Memory training", style="RailText.TLabel").pack(anchor="w")

        self.nav_buttons = {}
        for key, label in [
            ("dashboard", "Dashboard"),
            ("capture", "Capture"),
            ("review", "Review"),
            ("quiz", "Quiz"),
            ("shuffle", "Repetition"),
            ("tools", "Associations"),
            ("games", "Puzzles"),
            ("library", "Library"),
        ]:
            button = ttk.Button(self.rail, text=label, style="Nav.TButton", command=lambda view=key: self.show_view(view))
            button.pack(fill="x", padx=self.px(20), pady=self.px(5))
            self.nav_buttons[key] = button

        ttk.Label(self.rail, text="Data is saved locally on this PC.", style="RailText.TLabel", wraplength=self.px(230)).pack(side="bottom", padx=self.px(22), pady=self.px(26))

        self.main = ttk.Frame(root, style="Page.TFrame")
        self.main.pack(side="left", fill="both", expand=True)
        top = ttk.Frame(self.main, style="Page.TFrame")
        top.pack(fill="x", padx=self.px(36), pady=self.pad(28, 14))
        title_box = ttk.Frame(top, style="Page.TFrame")
        title_box.pack(side="left", fill="x", expand=True)
        self.eyebrow = ttk.Label(title_box, text="Today", style="Muted.TLabel")
        self.eyebrow.pack(anchor="w")
        self.title_label = ttk.Label(title_box, text="Dashboard", style="Title.TLabel")
        self.title_label.pack(anchor="w")
        ttk.Button(top, text="Export Data", command=self.export_data).pack(side="right")

        self.content = ttk.Frame(self.main, style="Page.TFrame")
        self.content.pack(fill="both", expand=True, padx=self.px(36), pady=(0, self.px(30)))
        self.toast_var = tk.StringVar()
        self.toast = tk.Label(self, textvariable=self.toast_var, bg=COLORS["rail"], fg=COLORS["white"], padx=self.px(20), pady=self.px(14), font=self.font("Segoe UI Semibold", 12))

    def show_view(self, view):
        titles = {
            "dashboard": ("Today", "Dashboard"),
            "capture": ("MemoryPal", "Capture Material"),
            "review": ("MemoryPal", "Spaced Review"),
            "quiz": ("MemoryPal", "Quick Quiz"),
            "shuffle": ("MemoryPal", "Repetition Path"),
            "tools": ("MemoryPal", "Associations"),
            "games": ("MemoryPal", "Puzzles"),
            "library": ("MemoryPal", "Library"),
        }
        self.current_view = view
        self.eyebrow.configure(text=titles[view][0])
        self.title_label.configure(text=titles[view][1])
        for key, button in self.nav_buttons.items():
            button.configure(style="ActiveNav.TButton" if key == view else "Nav.TButton")
        for child in self.content.winfo_children():
            child.destroy()
        getattr(self, f"view_{view}")()

    def toast_message(self, text):
        self.toast_var.set(text)
        self.toast.place(relx=1, rely=1, anchor="se", x=-self.px(24), y=-self.px(24))
        self.after(2600, self.toast.place_forget)

    def card(self, parent, style="Card.TFrame", padding=24):
        return ttk.Frame(parent, style=style, padding=self.px(padding))

    def text_box(self, parent, height=4, font_size=12):
        box = tk.Text(parent, height=height, wrap="word", bg=COLORS["white"], fg=COLORS["ink"], bd=0, relief="flat", highlightthickness=1, highlightbackground=COLORS["line"], highlightcolor=COLORS["primary"], padx=self.px(12), pady=self.px(12), font=self.font("Segoe UI", font_size))
        return box

    def solid_button(self, parent, text, command, color=COLORS["primary"]):
        return tk.Button(parent, text=text, command=command, bg=color, fg=COLORS["white"], activebackground=color, activeforeground=COLORS["white"], relief="flat", bd=0, cursor="hand2", font=self.font("Segoe UI Semibold", 11), padx=self.px(20), pady=self.px(11))

    def button_row(self, parent, buttons, style="Card.TFrame"):
        row = ttk.Frame(parent, style=style)
        row.pack(fill="x")
        for index, (label, command, button_style) in enumerate(buttons):
            ttk.Button(row, text=label, command=command, style=button_style).grid(row=0, column=index, sticky="ew", padx=(0 if index == 0 else self.px(8), 0))
            row.columnconfigure(index, weight=1, uniform="buttons")
        return row

    def view_dashboard(self):
        page = ScrollFrame(self.content)
        page.pack(fill="both", expand=True)

        hero = tk.Frame(page.inner, bg=COLORS["surface"], padx=28, pady=26, highlightthickness=1, highlightbackground=COLORS["line"])
        hero.pack(fill="x", padx=(0, 8), pady=(0, 16))
        hero.columnconfigure(0, weight=3)
        hero.columnconfigure(1, weight=2)
        tk.Label(hero, text="Ready for a short memory session?", bg=COLORS["surface"], fg=COLORS["ink"], font=("Segoe UI Semibold", 24)).grid(row=0, column=0, sticky="w")
        tk.Label(hero, text="Capture study bits, review what is due, or run a repetition path.", bg=COLORS["surface"], fg=COLORS["muted"], font=("Segoe UI", 13)).grid(row=1, column=0, sticky="w", pady=(8, 0))
        quick = tk.Frame(hero, bg=COLORS["surface"])
        quick.grid(row=0, column=1, rowspan=2, sticky="nsew")
        quick.columnconfigure(0, weight=1)
        quick.columnconfigure(1, weight=1)
        self.solid_button(quick, "Add Study Bits", lambda: self.show_view("capture")).grid(row=0, column=0, columnspan=2, sticky="ew", pady=(0, 10))
        self.solid_button(quick, "Start Review", lambda: self.show_view("review"), COLORS["green"]).grid(row=1, column=0, sticky="ew", padx=(0, 8))
        self.solid_button(quick, "Repetition Path", lambda: self.show_view("shuffle"), COLORS["orange"]).grid(row=1, column=1, sticky="ew")

        stats = ttk.Frame(page.inner, style="Page.TFrame")
        stats.pack(fill="x", padx=(0, 8))
        for index, (number, label, color) in enumerate([
            (len(self.store.due_cards()), "Due today", COLORS["primary"]),
            (len(self.store.cards), "Cards", COLORS["violet"]),
            (len(self.store.captures), "Captures", COLORS["cyan"]),
            (self.store.practiced, "Practiced", COLORS["orange"]),
        ]):
            tile = tk.Frame(stats, bg=COLORS["surface"], padx=20, pady=18, highlightthickness=1, highlightbackground=COLORS["line"])
            tile.grid(row=0, column=index, sticky="nsew", padx=(0 if index == 0 else 12, 0))
            tk.Frame(tile, bg=color, width=34, height=4).pack(anchor="w", pady=(0, 12))
            tk.Label(tile, text=str(number), bg=COLORS["surface"], fg=color, font=("Segoe UI Semibold", 34)).pack(anchor="w")
            tk.Label(tile, text=label, bg=COLORS["surface"], fg=COLORS["muted"], font=("Segoe UI", 12)).pack(anchor="w")
            stats.columnconfigure(index, weight=1)

        actions = ttk.Frame(page.inner, style="Page.TFrame")
        actions.pack(fill="x", padx=(0, 8), pady=(16, 0))
        cards = [
            ("Capture material", "Build separate study bits with text, image, audio, and video cues.", "capture", COLORS["orange"]),
            ("Spaced review", "Smart-check recall, reveal answers, and schedule next practice.", "review", COLORS["primary"]),
            ("Repetition path", "Practice chunks backwards, then walk back to the first item.", "shuffle", COLORS["green"]),
            ("Associations", "Turn material into acronyms, story routes, and recall hooks.", "tools", COLORS["violet"]),
            ("Puzzles", "Short recall games with large, steady controls.", "games", COLORS["pink"]),
            ("Library", "Browse captures, cards, media cues, and exports.", "library", COLORS["cyan"]),
        ]
        for index, (title, body, target, color) in enumerate(cards):
            frame = tk.Frame(actions, bg=COLORS["surface"], padx=24, pady=24, highlightthickness=1, highlightbackground=COLORS["line"])
            frame.grid(row=index // 2, column=index % 2, sticky="nsew", padx=(0 if index % 2 == 0 else 12, 0), pady=(0, 12))
            frame.columnconfigure(0, weight=1)
            tk.Frame(frame, bg=color, width=38, height=4).pack(anchor="w", pady=(0, 16))
            tk.Label(frame, text=title, bg=COLORS["surface"], fg=COLORS["ink"], font=("Segoe UI Semibold", 17)).pack(anchor="w")
            tk.Label(frame, text=body, bg=COLORS["surface"], fg=COLORS["muted"], font=("Segoe UI", 12), wraplength=460, justify="left").pack(anchor="w", pady=(8, 12))
            self.solid_button(frame, "Open", lambda view=target: self.show_view(view), color).pack(fill="x")
            actions.columnconfigure(index % 2, weight=1)

    def attach_media(self, kind, labels):
        filetypes = {
            "image": [("Images", "*.png *.jpg *.jpeg *.gif *.bmp *.webp")],
            "audio": [("Audio", "*.mp3 *.wav *.m4a *.ogg *.webm *.aac")],
            "video": [("Video", "*.mp4 *.mov *.avi *.mkv *.webm *.wmv")],
        }.get(kind, [("All files", "*.*")])
        selected = filedialog.askopenfilename(title=f"Choose {kind}", filetypes=filetypes + [("All files", "*.*")])
        if not selected:
            return
        ATTACHMENT_DIR.mkdir(parents=True, exist_ok=True)
        source = Path(selected)
        target = ATTACHMENT_DIR / f"{uuid4().hex}{source.suffix.lower()}"
        shutil.copy2(source, target)
        self.pending_media[kind] = str(target)
        labels[kind].configure(text=target.name)

    def view_capture(self):
        page = ScrollFrame(self.content)
        page.pack(fill="both", expand=True)
        wrapper = ttk.Frame(page.inner, style="Page.TFrame")
        wrapper.pack(fill="both", expand=True, padx=(0, 8))
        form = self.card(wrapper)
        form.pack(side="left", fill="both", expand=True, padx=(0, 14))
        side = self.card(wrapper, "AltCard.TFrame")
        side.pack(side="left", fill="both", expand=True)

        ttk.Label(form, text="Study set builder", style="H2.TLabel").pack(anchor="w")
        ttk.Label(form, text="Add each fact, reminder, or idea as its own bit.", style="CardMuted.TLabel").pack(anchor="w", pady=(6, 18))
        ttk.Label(form, text="Title", style="CardMuted.TLabel").pack(anchor="w")
        title = ttk.Entry(form)
        title.insert(0, "Chapter 3 key terms")
        title.pack(fill="x", pady=(4, 12))
        ttk.Label(form, text="Card prompt", style="CardMuted.TLabel").pack(anchor="w")
        prompt = ttk.Entry(form)
        prompt.insert(0, "What should I recall from bit {n}?")
        prompt.pack(fill="x", pady=(4, 12))

        ttk.Label(form, text="Study bit", style="CardMuted.TLabel").pack(anchor="w")
        entry = self.text_box(form, 4, 13)
        entry.pack(fill="x", pady=(4, 10))
        chunks = []
        count_label = ttk.Label(form, text="0 study bits added", style="CardMuted.TLabel")
        count_label.pack(anchor="w")
        chunk_panel = tk.Frame(form, bg=COLORS["surface"])
        chunk_panel.pack(fill="both", expand=True, pady=(8, 12))

        def refresh():
            for child in chunk_panel.winfo_children():
                child.destroy()
            if not chunks:
                tk.Label(chunk_panel, text="Add a bit or split a pasted list to build your study set.", bg=COLORS["surface"], fg=COLORS["muted"], font=("Segoe UI", 12), wraplength=520, justify="left").pack(anchor="w")
            for index, chunk in enumerate(chunks, 1):
                row = tk.Frame(chunk_panel, bg=COLORS["alt"], padx=14, pady=12)
                row.pack(fill="x", pady=(0, 8))
                tk.Label(row, text=f"{index}.", bg=COLORS["alt"], fg=COLORS["primary"], font=("Segoe UI Semibold", 12)).pack(side="left", anchor="n", padx=(0, 8))
                tk.Label(row, text=chunk, bg=COLORS["alt"], fg=COLORS["ink"], wraplength=520, justify="left", font=("Segoe UI", 12)).pack(side="left", fill="x", expand=True)
            count_label.configure(text=f"{len(chunks)} study bit{'s' if len(chunks) != 1 else ''} added")

        def add_bit():
            raw = entry.get("1.0", "end").strip()
            if not raw:
                self.toast_message("Type a study bit first.")
                return
            chunks.append(normalize_space(raw))
            entry.delete("1.0", "end")
            refresh()

        def split_paste():
            bits = split_study_bits(entry.get("1.0", "end"))
            if not bits:
                self.toast_message("Paste a few lines or facts first.")
                return
            chunks.extend(normalize_space(bit) for bit in bits)
            entry.delete("1.0", "end")
            refresh()

        def remove_last():
            if chunks:
                chunks.pop()
                refresh()

        self.button_row(form, [("Add Bit", add_bit, "Primary.TButton"), ("Split Paste", split_paste, "TButton"), ("Remove Last", remove_last, "TButton")])
        ttk.Label(form, text="Attach cues", style="CardMuted.TLabel").pack(anchor="w", pady=(16, 6))
        self.pending_media = {"image": "", "audio": "", "video": ""}
        labels = {kind: ttk.Label(side, text=f"No {kind} selected", style="AltCard.TLabel", wraplength=500) for kind in ("image", "audio", "video")}
        self.button_row(form, [("Add Image", lambda: self.attach_media("image", labels), "TButton"), ("Add Audio", lambda: self.attach_media("audio", labels), "TButton"), ("Add Video", lambda: self.attach_media("video", labels), "TButton")])

        def save(make_cards=False):
            title_text = normalize_space(title.get()) or "Captured memory material"
            draft = entry.get("1.0", "end").strip()
            final_chunks = list(chunks)
            if draft:
                final_chunks.extend(normalize_space(bit) for bit in split_study_bits(draft))
            if not final_chunks and not any(self.pending_media.values()):
                self.toast_message("Add a study bit or media cue first.")
                return
            capture = Capture(title=title_text, notes="\n".join(final_chunks), chunks=final_chunks, **self.pending_media)
            self.store.add_capture(capture)
            created = 0
            if make_cards:
                prompt_text = normalize_space(prompt.get()) or "What should I recall from bit {n}?"
                card_chunks = final_chunks or [f"Use the attached media to recall {title_text}."]
                for index, chunk in enumerate(card_chunks, 1):
                    front = prompt_text.replace("{n}", str(index)).replace("{total}", str(len(card_chunks)))
                    if front == prompt_text and len(card_chunks) > 1:
                        front = f"{front} ({index}/{len(card_chunks)})"
                    self.store.add_card(Card(deck="Captured Material", front=front, back=chunk, pathway=f"Capture > {title_text} > Bit {index}", association="Use attached media as a memory cue.", **self.pending_media))
                    created += 1
            chunks.clear()
            entry.delete("1.0", "end")
            refresh()
            self.pending_media = {"image": "", "audio": "", "video": ""}
            for kind, label in labels.items():
                label.configure(text=f"No {kind} selected")
            self.toast_message(f"Capture saved and {created} cards created." if make_cards else "Capture saved.")

        ttk.Frame(form, style="Card.TFrame").pack(pady=(10, 0))
        self.button_row(form, [("Save Capture", lambda: save(False), "Primary.TButton"), ("Make Cards", lambda: save(True), "TButton")])

        ttk.Label(side, text="Chunk-based capture", style="AltH2.TLabel").pack(anchor="w")
        ttk.Label(side, text="Each bit becomes its own reusable practice item.", style="AltCard.TLabel", wraplength=500).pack(anchor="w", pady=(10, 22))
        for label in labels.values():
            label.pack(anchor="w", pady=(0, 10))
        refresh()

    def media_summary(self, item):
        parts = []
        for kind in ("image", "audio", "video"):
            path = getattr(item, kind, "")
            if path:
                parts.append(f"{kind.title()}: {Path(path).name}")
        return " | ".join(parts)

    def open_media(self, path):
        if not path or not Path(path).exists():
            self.toast_message("Media file was not found.")
            return
        try:
            import os
            os.startfile(path)
        except OSError as exc:
            messagebox.showerror("Could not open media", str(exc))

    def render_media_controls(self, parent, item):
        media = [(kind, getattr(item, kind, "")) for kind in ("image", "audio", "video") if getattr(item, kind, "")]
        if not media:
            return
        ttk.Label(parent, text=self.media_summary(item), style="CardMuted.TLabel", wraplength=1040).pack(anchor="w", pady=(8, 4))
        row = ttk.Frame(parent, style="Card.TFrame")
        row.pack(fill="x", pady=(0, 8))
        for index, (kind, path) in enumerate(media):
            ttk.Button(row, text=f"Open {kind.title()}", command=lambda value=path: self.open_media(value)).grid(row=0, column=index, sticky="ew", padx=(0 if index == 0 else 8, 0))
            row.columnconfigure(index, weight=1)

    def view_review(self):
        page = ScrollFrame(self.content)
        page.pack(fill="both", expand=True)
        host = self.card(page.inner)
        host.pack(fill="both", expand=True, padx=(0, 8))
        self.render_review(host)

    def render_review(self, host, show_answer=False, assessment=None, response_text=""):
        for child in host.winfo_children():
            child.destroy()
        due = self.store.due_cards()
        if not due:
            ttk.Label(host, text="No cards due today", style="H2.TLabel").pack(anchor="w")
            ttk.Label(host, text="Capture new material or browse your library.", style="Card.TLabel").pack(anchor="w", pady=(8, 0))
            return
        if not self.current_review or self.current_review not in due:
            self.current_review = due[0]
        card = self.current_review
        ttk.Label(host, text=f"{card.deck} | Next review: {card.next_review}", style="CardMuted.TLabel").pack(anchor="w")
        ttk.Label(host, text=card.front, style="H2.TLabel", wraplength=1040).pack(anchor="w", pady=(10, 16))
        self.render_media_controls(host, card)
        if show_answer:
            if response_text:
                ttk.Label(host, text=f"Your response: {response_text}", style="CardMuted.TLabel", wraplength=1040).pack(anchor="w", pady=(0, 10))
            if assessment:
                ttk.Label(host, text=f"Smart check: {assessment['label']} | {assessment['score']}% | Bucket: {assessment['bucket']} | Reps: {assessment['repetitions']}", style="H2.TLabel", wraplength=1040).pack(anchor="w", pady=(0, 8))
                ttk.Label(host, text=assessment["detail"], style="CardMuted.TLabel", wraplength=1040).pack(anchor="w", pady=(0, 12))
            ttk.Label(host, text=card.back, style="Card.TLabel", wraplength=1040).pack(anchor="w", pady=(0, 14))
            ttk.Label(host, text=f"Path: {card.pathway or 'Not set'}", style="CardMuted.TLabel").pack(anchor="w")
            ttk.Label(host, text=f"Hook: {card.association or 'Not set'}", style="CardMuted.TLabel").pack(anchor="w", pady=(0, 16))
            row = ttk.Frame(host, style="Card.TFrame")
            row.pack(fill="x")
            if assessment:
                ttk.Button(row, text=f"Use Smart Rating ({assessment['bucket']})", style="Primary.TButton", command=lambda: self.rate_review(host, assessment["quality"])).grid(row=0, column=0, sticky="ew", padx=(0, 8))
                row.columnconfigure(0, weight=2)
                offset = 1
            else:
                offset = 0
            for index, (label, quality) in enumerate([("Again", 1), ("Good", 4), ("Easy", 5)]):
                ttk.Button(row, text=label, command=lambda value=quality: self.rate_review(host, value)).grid(row=0, column=index + offset, sticky="ew", padx=(0 if index == 0 and not offset else 8, 0))
                row.columnconfigure(index + offset, weight=1)
            return

        ttk.Label(host, text="Type your answer, transcript, or media description.", style="Card.TLabel").pack(anchor="w", pady=(0, 10))
        response = self.text_box(host, 5)
        response.pack(fill="x", pady=(0, 10))

        def smart_check():
            context = " ".join(part for part in [card.front, card.pathway, card.association, self.media_summary(card)] if part)
            result = answer_assessment(response.get("1.0", "end").strip(), card.back, context)
            self.render_review(host, True, result, response.get("1.0", "end").strip())

        self.button_row(host, [("Smart Check", smart_check, "Primary.TButton"), ("Reveal Only", lambda: self.render_review(host, True), "TButton")])

    def rate_review(self, host, quality):
        self.store.schedule(self.current_review, quality)
        self.current_review = None
        self.toast_message("Review scheduled.")
        self.render_review(host)

    def view_quiz(self):
        page = ScrollFrame(self.content)
        page.pack(fill="both", expand=True)
        host = self.card(page.inner)
        host.pack(fill="both", expand=True, padx=(0, 8))
        self.quiz_cards = random.sample(self.store.cards, min(5, len(self.store.cards))) if self.store.cards else []
        self.quiz_round = 0
        self.quiz_score = 0
        self.render_quiz(host)

    def render_quiz(self, host):
        for child in host.winfo_children():
            child.destroy()
        if not self.store.cards:
            ttk.Label(host, text="Add cards first", style="H2.TLabel").pack(anchor="w")
            return
        mode = ttk.Frame(host, style="Card.TFrame")
        mode.pack(fill="x", pady=(0, 16))
        ttk.Button(mode, text="Self Check", style="Primary.TButton" if self.quiz_mode == "self" else "TButton", command=lambda: self.set_quiz_mode(host, "self")).grid(row=0, column=0, sticky="ew", padx=(0, 8))
        ttk.Button(mode, text="Multiple Choice", style="Primary.TButton" if self.quiz_mode == "choices" else "TButton", command=lambda: self.set_quiz_mode(host, "choices")).grid(row=0, column=1, sticky="ew")
        mode.columnconfigure(0, weight=1)
        mode.columnconfigure(1, weight=1)

        if self.quiz_mode == "choices" and len(self.store.cards) < 2:
            ttk.Label(host, text="Multiple Choice needs at least two cards.", style="H2.TLabel").pack(anchor="w")
            return
        if self.quiz_round >= len(self.quiz_cards):
            summary = f"Score: {self.quiz_score} / {len(self.quiz_cards)}" if self.quiz_mode == "choices" else f"Completed: {len(self.quiz_cards)} cards"
            ttk.Label(host, text=summary, style="H2.TLabel").pack(anchor="w")
            ttk.Button(host, text="Play Again", style="Primary.TButton", command=lambda: self.show_view("quiz")).pack(fill="x", pady=(16, 0))
            return
        card = self.quiz_cards[self.quiz_round]
        ttk.Label(host, text=f"Question {self.quiz_round + 1} of {len(self.quiz_cards)}", style="CardMuted.TLabel").pack(anchor="w")
        ttk.Label(host, text=card.front, style="H2.TLabel", wraplength=1040).pack(anchor="w", pady=(10, 20))
        self.render_media_controls(host, card)
        if self.quiz_mode == "choices":
            wrong = [item.back for item in self.store.cards if item.id != card.id]
            choices = random.sample(wrong, min(3, len(wrong))) + [card.back]
            random.shuffle(choices)
            for choice in choices:
                ttk.Button(host, text=choice, command=lambda value=choice: self.answer_quiz(host, value, card.back)).pack(fill="x", pady=5)
            return
        response = self.text_box(host, 4)
        response.pack(fill="x", pady=(0, 8))
        result = ttk.Label(host, text="Answer it yourself, then smart-check or reveal.", style="CardMuted.TLabel", wraplength=1040)
        result.pack(anchor="w", pady=(0, 8))
        answer_box = ttk.Frame(host, style="Card.TFrame")
        visible = {"value": False}

        def reveal():
            if visible["value"]:
                answer_box.pack_forget()
                visible["value"] = False
                return
            for child in answer_box.winfo_children():
                child.destroy()
            ttk.Label(answer_box, text="Answer", style="CardMuted.TLabel").pack(anchor="w")
            ttk.Label(answer_box, text=card.back, style="Card.TLabel", wraplength=1040).pack(anchor="w", pady=(4, 0))
            answer_box.pack(fill="x", pady=(4, 10))
            visible["value"] = True

        def smart_check():
            checked = answer_assessment(response.get("1.0", "end").strip(), card.back, card.front)
            result.configure(text=f"{checked['label']} | {checked['score']}% | Reps: {checked['repetitions']} | {checked['detail']}")

        self.button_row(host, [("Smart Check", smart_check, "Primary.TButton"), ("Reveal / Hide Answer", reveal, "TButton"), ("Next", lambda: self.next_self_quiz(host), "TButton")])

    def set_quiz_mode(self, host, mode):
        self.quiz_mode = mode
        self.quiz_round = 0
        self.quiz_score = 0
        self.quiz_cards = random.sample(self.store.cards, min(5, len(self.store.cards)))
        self.render_quiz(host)

    def next_self_quiz(self, host):
        self.quiz_round += 1
        self.render_quiz(host)

    def answer_quiz(self, host, choice, answer):
        if choice == answer:
            self.quiz_score += 1
            self.toast_message("Correct.")
        else:
            self.toast_message(f"Answer: {answer}")
        self.quiz_round += 1
        self.render_quiz(host)

    def practice_text(self, source="all"):
        lines = []
        if source in ("all", "captures"):
            for capture in self.store.captures:
                for index, bit in enumerate(capture.chunks or split_study_bits(capture.notes), 1):
                    lines.append(f"{capture.title} - bit {index} => {bit}")
        if source in ("all", "cards"):
            for card in self.store.cards:
                if card.back:
                    lines.append(f"{card.front or card.deck} => {card.back}")
        return "\n".join(lines)

    def practice_items_from_text(self, raw):
        raw = (raw or "").replace("\\n", "\n").replace("/n", "\n")
        lines = [line.strip() for line in raw.splitlines() if line.strip()]
        if len(lines) < 2:
            lines = split_study_bits(raw)
        items = []
        for index, line in enumerate(lines, 1):
            prompt, answer = "", line
            for delimiter in ("=>", "::"):
                if delimiter in line:
                    prompt, answer = line.split(delimiter, 1)
                    prompt, answer = normalize_space(prompt), normalize_space(answer)
                    break
            items.append({"prompt": prompt or f"Study bit {index}", "answer": answer})
        return [item for item in items if item["answer"]]

    @staticmethod
    def repetition_steps(bits, start, span):
        if not bits:
            return []
        start_index = min(max(start, 1), len(bits)) - 1
        span = start_index + 1 if span is None else min(max(span, 1), len(bits))
        steps, current = [], []
        for offset in range(span):
            index = start_index - offset
            if index < 0:
                break
            current.append(index)
            steps.append(("-".join(str(item + 1) for item in current), list(current)))
        if current and current[-1] > 0:
            walk = list(range(current[-1], -1, -1))
            steps.append(("-".join(str(item + 1) for item in walk), walk))
        return steps

    def view_shuffle(self):
        wrapper = ttk.Frame(self.content, style="Page.TFrame")
        wrapper.pack(fill="both", expand=True)
        panel = self.card(wrapper)
        panel.pack(fill="x")
        ttk.Label(panel, text="Repetition path", style="H2.TLabel").pack(anchor="w")
        ttk.Label(panel, text="Use question => answer lines. Prompts show first; answers reveal when you choose.", style="CardMuted.TLabel", wraplength=980).pack(anchor="w", pady=(6, 14))
        text = self.text_box(panel, 7, 13)
        text.pack(fill="x", pady=(0, 12))

        controls = ttk.Frame(panel, style="Card.TFrame")
        controls.pack(fill="x", pady=(0, 12))
        ttk.Label(controls, text="Start #", style="CardMuted.TLabel").grid(row=0, column=0, sticky="w")
        start_var = tk.StringVar()
        ttk.Entry(controls, textvariable=start_var).grid(row=1, column=0, sticky="ew", padx=(0, 8))
        ttk.Label(controls, text="Loop range (optional)", style="CardMuted.TLabel").grid(row=0, column=1, sticky="w")
        range_var = tk.StringVar()
        ttk.Entry(controls, textvariable=range_var).grid(row=1, column=1, sticky="ew", padx=(0, 8))
        ttk.Label(controls, text="Example: range 3 at item 5 gives 5, 5-4, 5-4-3, then 3-2-1.", style="CardMuted.TLabel", wraplength=620).grid(row=1, column=2, sticky="w")
        controls.columnconfigure(0, weight=1)
        controls.columnconfigure(1, weight=1)
        controls.columnconfigure(2, weight=3)

        results = ScrollFrame(wrapper)
        results.pack(fill="both", expand=True, pady=(14, 0))

        def load(source):
            text.delete("1.0", "end")
            text.insert("1.0", self.practice_text(source))
            self.toast_message("Loaded saved material.")

        def build():
            for child in results.inner.winfo_children():
                child.destroy()
            items = self.practice_items_from_text(text.get("1.0", "end"))
            if not items:
                ttk.Label(results.inner, text="Paste material or load saved cards/captures first.", style="Muted.TLabel").pack(anchor="w")
                return
            try:
                start = int(start_var.get()) if start_var.get().strip() else len(items)
                span = int(range_var.get()) if range_var.get().strip() else None
            except ValueError:
                self.toast_message("Start and range must be numbers.")
                return
            answers = [item["answer"] for item in items]
            for round_number, (label, indexes) in enumerate(self.repetition_steps(answers, start, span), 1):
                item_card = self.card(results.inner)
                item_card.pack(fill="x", padx=(0, 8), pady=(0, 8))
                ttk.Label(item_card, text=f"Round {round_number} | Repeat {label}", style="H2.TLabel").pack(anchor="w")
                ttk.Label(item_card, text="Prompt", style="CardMuted.TLabel").pack(anchor="w", pady=(8, 0))
                for index in indexes:
                    ttk.Label(item_card, text=f"{index + 1}. {items[index]['prompt']}", style="Card.TLabel", wraplength=1080).pack(anchor="w", pady=(4, 0))
                response = self.text_box(item_card, 3, 11)
                response.pack(fill="x", pady=(10, 6))
                result = ttk.Label(item_card, text="Type your recall, then check or reveal.", style="CardMuted.TLabel", wraplength=1040)
                result.pack(anchor="w")
                answer_frame = ttk.Frame(item_card, style="Card.TFrame")
                visible = {"value": False}

                def reveal(frame=answer_frame, ids=indexes, flag=visible):
                    if flag["value"]:
                        frame.pack_forget()
                        flag["value"] = False
                        return
                    for child in frame.winfo_children():
                        child.destroy()
                    ttk.Label(frame, text="Answer", style="CardMuted.TLabel").pack(anchor="w")
                    for answer_index in ids:
                        ttk.Label(frame, text=f"{answer_index + 1}. {items[answer_index]['answer']}", style="Card.TLabel", wraplength=1080).pack(anchor="w", pady=(3, 0))
                    frame.pack(fill="x", pady=(8, 0))
                    flag["value"] = True

                def check(box=response, target=result, ids=indexes):
                    expected = "\n".join(items[index]["answer"] for index in ids)
                    checked = answer_assessment(box.get("1.0", "end").strip(), expected)
                    target.configure(text=f"{checked['label']} | {checked['score']}% | Reps: {checked['repetitions']} | {checked['detail']}")

                self.button_row(item_card, [("Smart Check", check, "Primary.TButton"), ("Reveal / Hide Answer", reveal, "TButton")])

        self.button_row(panel, [("Build Path", build, "Primary.TButton"), ("Use Captures", lambda: load("captures"), "TButton"), ("Use Cards", lambda: load("cards"), "TButton"), ("Use All", lambda: load("all"), "TButton")])

    def material_bits(self):
        bits = []
        for capture in self.store.captures:
            bits.extend(capture.chunks or split_study_bits(capture.notes))
        for card in self.store.cards:
            bits.extend([card.front, card.back])
        return [bit for bit in bits if bit]

    def view_tools(self):
        wrapper = ttk.Frame(self.content, style="Page.TFrame")
        wrapper.pack(fill="both", expand=True)
        panel = self.card(wrapper)
        panel.pack(fill="x")
        ttk.Label(panel, text="Ideas", style="CardMuted.TLabel").pack(anchor="w")
        ideas = ttk.Entry(panel)
        ideas.insert(0, "mitosis, meiosis, chromosomes")
        ideas.pack(fill="x", pady=(4, 12))
        output = self.card(wrapper, "AltCard.TFrame")
        output.pack(fill="both", expand=True, pady=(14, 0))
        out = ttk.Label(output, text="Your memory hook will appear here.", style="AltCard.TLabel", wraplength=1080)
        out.pack(anchor="w")

        def parse():
            return [item.strip() for item in re.split(r"[,\n;|]+", ideas.get().replace("/n", "\n")) if item.strip()]

        def acronym():
            items = parse()
            out.configure(text="".join(item[0].upper() for item in items) + "\n\nConnect each letter back to: " + ", ".join(items) if items else "Add ideas first.")

        def story():
            items = parse()
            out.configure(text=f"Imagine walking through: {' -> '.join(items)}.\n\nTurn each stop into a clear picture." if items else "Add ideas first.")

        def saved():
            ideas.delete(0, "end")
            ideas.insert(0, ", ".join(self.material_bits()[:8]))

        self.button_row(panel, [("Acronym", acronym, "Primary.TButton"), ("Mini Story", story, "TButton"), ("Saved Material", saved, "TButton")])

    def view_games(self):
        wrapper = ttk.Frame(self.content, style="Page.TFrame")
        wrapper.pack(fill="both", expand=True)
        left = self.card(wrapper)
        left.pack(side="left", fill="both", expand=True, padx=(0, 14))
        right = self.card(wrapper)
        right.pack(side="left", fill="both", expand=True)
        ttk.Label(left, text="Sequence Recall", style="H2.TLabel").pack(anchor="w")
        sequence_box = ttk.Label(left, text="Press Start", style="Stat.TLabel", wraplength=500)
        sequence_box.pack(anchor="w", pady=(20, 16))
        answer = ttk.Entry(left)
        answer.pack(fill="x", pady=(0, 12))

        def start_sequence():
            self.sequence = "".join(str(random.randint(1, 9)) for _ in range(random.randint(4, 7)))
            sequence_box.configure(text=" ".join(self.sequence))
            answer.delete(0, "end")
            self.after(2800, lambda: sequence_box.configure(text="Now type it"))

        def check_sequence():
            typed = re.sub(r"\D", "", answer.get())
            self.toast_message("Correct." if typed == self.sequence else f"Sequence: {self.sequence}")

        self.button_row(left, [("Start", start_sequence, "Primary.TButton"), ("Check", check_sequence, "TButton")])

        ttk.Label(right, text="Word Recall", style="H2.TLabel").pack(anchor="w")
        word_box = ttk.Label(right, text="Press Show Words", style="Card.TLabel", wraplength=500)
        word_box.pack(anchor="w", pady=(20, 16))
        word_answer = ttk.Entry(right)
        word_answer.pack(fill="x", pady=(0, 12))
        current_words = []

        def show_words():
            nonlocal current_words
            pool = [word for bit in self.material_bits() for word in re.findall(r"[A-Za-z][A-Za-z'-]{2,}", bit)]
            if len(pool) < 5:
                pool = ["river", "lamp", "garden", "silver", "window", "music", "orange"]
            current_words = random.sample(pool, 5)
            word_box.configure(text=", ".join(current_words))
            word_answer.delete(0, "end")
            self.after(3600, lambda: word_box.configure(text="Say them back"))

        def check_words():
            result = answer_assessment(word_answer.get(), " ".join(current_words))
            self.toast_message(f"{result['label']} | {result['score']}%")

        self.button_row(right, [("Show Words", show_words, "Primary.TButton"), ("Smart Check", check_words, "TButton")])

    def view_library(self):
        tools = ttk.Frame(self.content, style="Page.TFrame")
        tools.pack(fill="x", pady=(0, 12))
        self.button_row(tools, [("Add Samples", lambda: [self.store.add_card(card) for card in sample_cards()] or self.show_view("library"), "Primary.TButton"), ("Import", self.import_data, "TButton"), ("Reset", self.reset_data, "Danger.TButton")], "Page.TFrame")
        page = ScrollFrame(self.content)
        page.pack(fill="both", expand=True)
        if not self.store.captures and not self.store.cards:
            ttk.Label(page.inner, text="No material yet.", style="Muted.TLabel").pack(anchor="w")
            return
        for capture in self.store.captures:
            item = self.card(page.inner)
            item.pack(fill="x", padx=(0, 8), pady=(0, 10))
            chunks = capture.chunks or split_study_bits(capture.notes)
            ttk.Label(item, text=f"Capture | {capture.created_at}", style="CardMuted.TLabel").pack(anchor="w")
            ttk.Label(item, text=capture.title, style="H2.TLabel", wraplength=1060).pack(anchor="w", pady=(6, 5))
            ttk.Label(item, text=f"{len(chunks)} study bits", style="CardMuted.TLabel").pack(anchor="w")
            for index, chunk in enumerate(chunks[:5], 1):
                ttk.Label(item, text=f"{index}. {chunk}", style="Card.TLabel", wraplength=1080).pack(anchor="w", pady=(2, 0))
            self.render_media_controls(item, capture)
        for card in self.store.cards:
            item = self.card(page.inner)
            item.pack(fill="x", padx=(0, 8), pady=(0, 10))
            ttk.Label(item, text=f"{card.deck} | Next: {card.next_review}", style="CardMuted.TLabel").pack(anchor="w")
            ttk.Label(item, text=card.front, style="H2.TLabel", wraplength=1060).pack(anchor="w", pady=(6, 5))
            ttk.Label(item, text=card.back, style="Card.TLabel", wraplength=1080).pack(anchor="w")
            ttk.Label(item, text=f"Path: {card.pathway or 'Not set'}", style="CardMuted.TLabel").pack(anchor="w", pady=(8, 0))
            self.render_media_controls(item, card)

    def export_data(self):
        path = filedialog.asksaveasfilename(title="Export MemoryPal data", defaultextension=".json", initialfile="memorypal-data.json", filetypes=[("JSON files", "*.json")])
        if path:
            self.store.save()
            shutil.copy2(DATA_FILE, path)
            self.toast_message("Data exported.")

    def import_data(self):
        path = filedialog.askopenfilename(title="Import MemoryPal data", filetypes=[("JSON files", "*.json")])
        if not path:
            return
        try:
            raw = json.loads(Path(path).read_text(encoding="utf-8"))
            self.store.cards = [Card.from_dict(item) for item in raw.get("cards", [])]
            self.store.captures = [Capture.from_dict(item) for item in raw.get("captures", [])]
            self.store.practiced = int(raw.get("practiced", 0))
            self.store.save()
            self.show_view("library")
        except (OSError, json.JSONDecodeError, ValueError) as exc:
            messagebox.showerror("Import failed", str(exc))

    def reset_data(self):
        if messagebox.askyesno("Reset MemoryPal", "Clear local data and restore sample cards?"):
            self.store.reset()
            self.show_view("library")


def main():
    enable_dpi_awareness()
    app = MemoryPalApp()
    app.mainloop()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
