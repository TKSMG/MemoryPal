from MemoryPal_stage_common import run_stage


run_stage(
    "v04 Alpha",
    "Media support beyond flashcards",
    [
        "Capture supports image, audio, and video cues.",
        "Saved material can carry media into review, quiz, library, and related practice modes.",
        "Media files are copied into local MemoryPal data storage.",
    ],
)
