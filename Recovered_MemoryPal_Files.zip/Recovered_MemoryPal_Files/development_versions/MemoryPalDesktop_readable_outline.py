"""
MemoryPalDesktop_readable_outline.py

This is a human-readable guide to the current recovered MemoryPal program structure.

The working program itself is:

    ../latest_app/MemoryPalDesktop.py

This file exists so someone reading the project later can understand how the
single-file app is organized without having to decode the whole source at once.
It does not replace the app.
"""


SOURCE_FILE = "../latest_app/MemoryPalDesktop.py"


PROGRAM_MAP = [
    (
        "Configuration",
        [
            "App name and data paths.",
            "Default window sizes.",
            "Color palette.",
            "DPI-awareness helper for Windows.",
        ],
    ),
    (
        "Smart-check helpers",
        [
            "normalize_space cleans user text.",
            "split_study_bits turns pasted notes into chunks.",
            "text_tokens extracts comparable words.",
            "answer_assessment scores how close a response is to the expected answer.",
        ],
    ),
    (
        "Data models",
        [
            "Card stores prompt, answer, pathway, association, media, and scheduling data.",
            "Capture stores a title, notes, separated chunks, media, and creation time.",
        ],
    ),
    (
        "Persistence",
        [
            "MemoryStore loads and saves JSON data locally.",
            "Review scheduling updates intervals, repetitions, ease, and lapses.",
        ],
    ),
    (
        "Reusable UI pieces",
        [
            "ScrollFrame gives long screens a vertical scrollbar.",
            "card_frame creates consistent panels.",
            "button_grid keeps action rows evenly spaced.",
            "media helpers attach, preview, and open image/audio/video files.",
        ],
    ),
    (
        "Main app shell",
        [
            "MemoryPalApp builds the sidebar, top bar, content area, and toast messages.",
            "show_view switches between dashboard, capture, review, quiz, repetition, tools, games, and library.",
        ],
    ),
    (
        "Dashboard",
        [
            "Shows quick actions.",
            "Shows counts for due cards, total cards, captures, and practised items.",
            "Provides entry points into the main modes.",
        ],
    ),
    (
        "Capture",
        [
            "Lets the user add study bits one at a time.",
            "Can split pasted material into multiple chunks.",
            "Can attach image, audio, and video cues.",
            "Can create one card per chunk.",
        ],
    ),
    (
        "Review",
        [
            "Shows due cards.",
            "Lets the user type an answer.",
            "Supports Smart Check and manual reveal.",
            "Schedules the card based on the chosen or suggested quality.",
        ],
    ),
    (
        "Quiz",
        [
            "Self Check mode: user answers, reveals, or smart-checks.",
            "Multiple Choice mode: user chooses from answer options.",
        ],
    ),
    (
        "Repetition Path",
        [
            "Accepts question/title => answer material.",
            "Shows prompts first.",
            "Uses the start/range pattern.",
            "Example: 5, 5-4, 5-4-3, then 3-2-1.",
        ],
    ),
    (
        "Associations and Games",
        [
            "Associations creates acronyms and mini-stories.",
            "Puzzles include sequence recall and word recall.",
        ],
    ),
    (
        "Library",
        [
            "Shows captures as study-bit sets.",
            "Shows cards with paths, hooks, and media.",
            "Supports import, export, and reset.",
        ],
    ),
]


def print_program_map():
    print("MemoryPal readable program map")
    print("=" * 34)
    print(f"Working source: {SOURCE_FILE}")
    print()
    for section, notes in PROGRAM_MAP:
        print(section)
        print("-" * len(section))
        for note in notes:
            print(f"- {note}")
        print()


if __name__ == "__main__":
    print_program_map()
