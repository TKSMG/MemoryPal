# MemoryPal Development Stage Files

These files are reconstructed milestone prototypes based on the revision history in this thread.

They are not exact historical source snapshots, because the earlier source states were not saved as separate files. Instead, each file records one development stage as a small runnable Python prototype with the features that were added at that point.

Current recovered working app:

`../latest_app/MemoryPalDesktop.py`

Readable guide/copy:

`MemoryPalDesktop_readable_outline.py`

Human notesheet:

`../notes/MemoryPal_Memory_Techniques_Human_Notesheet.md`

## Stages

- `MemoryPal_v01_alpha_initial_pc_app.py` - Alpha: initial runnable PC app.
- `MemoryPal_v02_alpha_scaled_ui.py` - Alpha: scaled UI resolution.
- `MemoryPal_v03_alpha_multibit_shuffle.py` - Alpha: multiple study bits and newline parsing.
- `MemoryPal_v04_alpha_multimedia_capture.py` - Alpha: media support beyond flashcards.
- `MemoryPal_v05_beta_modern_ui.py` - Beta: first modern UI pass.
- `MemoryPal_v06_beta_static_brand.py` - Beta: removed decorative animation.
- `MemoryPal_v07_beta_structured_revision.py` - Beta: structured non-random revision path.
- `MemoryPal_v08_beta_notes_and_design.py` - Beta: notesheet and design artifacts.
- `MemoryPal_v09_test_button_scaling.py` - Test: home button scaling fixes.
- `MemoryPal_v10_test_repetition_and_smart_check.py` - Test: start/range repetition and smart checking.
- `MemoryPal_v11_test_native_multimedia.py` - Test: text, image, audio, and video support.
- `MemoryPal_v12_test_chunk_cards.py` - Test: chunk-based capture and card creation.
- `MemoryPal_v13_test_scrollable_forms.py` - Test: scrollable practice and capture screens.
- `MemoryPal_v14_test_walkback_repetition.py` - Test: final walk-back repetition rule.
- `MemoryPal_v15_beta_polished_dashboard.py` - Beta: modernized dashboard and shell.
- `MemoryPal_v16_test_prompt_answer_modes.py` - Test: prompt-answer practice modes.

## How to Run One

Open a terminal in this folder and run, for example:

```powershell
python MemoryPal_v14_test_walkback_repetition.py
```

Each file opens a small window summarizing that stage.
