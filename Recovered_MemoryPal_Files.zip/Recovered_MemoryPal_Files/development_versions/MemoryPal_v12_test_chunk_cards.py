from MemoryPal_stage_common import run_stage


run_stage(
    "v12 Test",
    "Chunk-based capture and card creation",
    [
        "Capture becomes a study-set builder.",
        "Each study bit is stored separately.",
        "Make Cards creates one card per chunk.",
    ],
)
