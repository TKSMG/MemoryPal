from MemoryPal_stage_common import run_stage


run_stage(
    "v02 Alpha",
    "Scaled UI resolution",
    [
        "Larger default window.",
        "Higher minimum size.",
        "DPI-aware sizing for Windows.",
    ],
)
