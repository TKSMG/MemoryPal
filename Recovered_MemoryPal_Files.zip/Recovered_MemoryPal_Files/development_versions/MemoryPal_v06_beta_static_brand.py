from MemoryPal_stage_common import run_stage


run_stage(
    "v06 Beta",
    "Removed decorative animation",
    [
        "Top/brand animation removed for a calmer interface.",
        "Less distraction for elderly users and learners.",
        "The app starts feeling quieter and more focused.",
    ],
)
