from MemoryPal_stage_common import run_stage


run_stage(
    "v13 Test",
    "Scrollable practice and capture screens",
    [
        "Long capture/review/quiz screens become scrollable.",
        "Buttons no longer disappear below the window.",
        "The app becomes easier to use on smaller screens.",
    ],
)
