from MemoryPal_stage_common import run_stage


run_stage(
    "v14 Test",
    "Final walk-back repetition rule",
    [
        "After the range loop, repetition walks from the last reached item to item 1.",
        "Example: 5, 5-4, 5-4-3, then 3-2-1.",
        "The rule matches the intended memory-revision pattern.",
    ],
    show_repetition=True,
)
