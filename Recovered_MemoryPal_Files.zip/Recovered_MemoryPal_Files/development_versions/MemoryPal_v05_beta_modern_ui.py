from MemoryPal_stage_common import run_stage


run_stage(
    "v05 Beta",
    "First modern UI pass",
    [
        "Cleaner color palette.",
        "Larger cards and buttons.",
        "Dashboard/action cards replace the plain desktop-form look.",
    ],
)
