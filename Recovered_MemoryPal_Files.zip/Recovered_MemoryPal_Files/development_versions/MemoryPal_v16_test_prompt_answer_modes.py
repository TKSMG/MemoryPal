from MemoryPal_stage_common import run_stage


run_stage(
    "v16 Test",
    "Prompt-answer practice modes",
    [
        "Repetition supports question/title => answer lines.",
        "Quiz gains Self Check and Multiple Choice modes.",
        "Users can answer themselves, reveal, or Smart Check.",
    ],
    show_repetition=True,
)
