import tkinter as tk
from tkinter import ttk


def repetition_path(count=5, start=5, span=3):
    if count <= 0:
        return []
    start_index = min(max(start, 1), count) - 1
    span = start_index + 1 if span is None else min(max(span, 1), count)
    steps = []
    current = []
    for offset in range(span):
        index = start_index - offset
        if index < 0:
            break
        current.append(index)
        steps.append("-".join(str(item + 1) for item in current))
    if current and current[-1] > 0:
        steps.append("-".join(str(item + 1) for item in range(current[-1], -1, -1)))
    return steps


class StageApp(tk.Tk):
    def __init__(self, version, title, features, show_repetition=False):
        super().__init__()
        self.title(f"MemoryPal {version}")
        self.geometry("900x560")
        self.minsize(760, 480)
        self.configure(bg="#f6f7fb")

        shell = ttk.Frame(self, padding=24)
        shell.pack(fill="both", expand=True)
        shell.columnconfigure(0, weight=1)

        ttk.Label(shell, text=f"MemoryPal {version}", font=("Segoe UI Semibold", 24)).grid(row=0, column=0, sticky="w")
        ttk.Label(shell, text=title, font=("Segoe UI", 13)).grid(row=1, column=0, sticky="w", pady=(4, 18))

        card = ttk.Frame(shell, padding=18)
        card.grid(row=2, column=0, sticky="nsew")
        shell.rowconfigure(2, weight=1)
        card.columnconfigure(0, weight=1)

        ttk.Label(card, text="What this stage added", font=("Segoe UI Semibold", 14)).grid(row=0, column=0, sticky="w")
        for number, feature in enumerate(features, start=1):
            ttk.Label(card, text=f"{number}. {feature}", wraplength=780, justify="left").grid(
                row=number, column=0, sticky="w", pady=(8, 0)
            )

        if show_repetition:
            example = ", ".join(repetition_path(count=5, start=5, span=3))
            ttk.Label(card, text=f"Example repetition path: {example}", font=("Segoe UI Semibold", 12)).grid(
                row=len(features) + 1, column=0, sticky="w", pady=(20, 0)
            )


def run_stage(version, title, features, show_repetition=False):
    app = StageApp(version, title, features, show_repetition)
    app.mainloop()
