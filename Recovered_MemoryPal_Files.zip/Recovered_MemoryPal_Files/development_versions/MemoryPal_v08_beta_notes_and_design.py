from MemoryPal_stage_common import run_stage


run_stage(
    "v08 Beta",
    "Notesheet and design artifacts",
    [
        "Memory techniques documented.",
        "Initial dashboard, repetition path, and accessible mode mockups created.",
        "Project starts gaining design/development records alongside code.",
    ],
)
