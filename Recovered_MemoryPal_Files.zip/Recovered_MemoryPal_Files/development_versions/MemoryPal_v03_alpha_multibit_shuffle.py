from MemoryPal_stage_common import run_stage


run_stage(
    "v03 Alpha",
    "Multiple study bits and newline parsing",
    [
        "Study text can split by real newlines, /n, numbered lists, commas, and separators.",
        "Revision can work on more than one bit of information.",
        "Long pasted notes start becoming structured practice material.",
    ],
)
