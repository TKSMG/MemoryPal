from MemoryPal_stage_common import run_stage


run_stage(
    "v01 Alpha",
    "Initial runnable PC app",
    [
        "Single-file Python/Tkinter desktop app.",
        "Basic memory trainer shell.",
        "First pass at capture, review, quiz, associations, games, and library.",
    ],
)
