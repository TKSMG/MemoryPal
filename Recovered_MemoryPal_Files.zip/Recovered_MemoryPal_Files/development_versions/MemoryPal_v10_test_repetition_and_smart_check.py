from MemoryPal_stage_common import run_stage


run_stage(
    "v10 Test",
    "Start/range repetition and smart checking",
    [
        "Shuffle becomes a repetition path with start number and range.",
        "Smart Check scores typed responses against expected answers.",
        "Review buckets and repetition suggestions become adaptive.",
    ],
    show_repetition=True,
)
