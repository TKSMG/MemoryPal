from MemoryPal_stage_common import run_stage


run_stage(
    "v09 Test",
    "Home button scaling fixes",
    [
        "Dashboard buttons adjusted so labels do not clip at smaller window sizes.",
        "Open buttons and card spacing made more stable.",
        "UI starts handling non-fullscreen windows better.",
    ],
)
