from MemoryPal_stage_common import run_stage


run_stage(
    "v15 Beta",
    "Modernized dashboard and shell",
    [
        "Dashboard gets quick actions and cleaner mode cards.",
        "Sidebar labels and app shell are calmer and more polished.",
        "The home screen becomes easier to understand at a glance.",
    ],
)
