# MemoryPal Memory Techniques Notesheet

This is a simple working notesheet for the memory ideas used in MemoryPal. It is written to be easy to read later, not to look like a polished report.

## The Main Idea

MemoryPal is meant to help someone remember things by breaking information into small study bits, showing prompts, letting the user answer from memory, and then giving gentle ways to check or repeat the answer.

The app is especially aimed at learners and elderly users, so the methods should stay simple, calm, and predictable.

## Study Bits

A study bit is one small thing to remember.

Examples:

- A definition.
- A date.
- A person's name.
- A medication reminder.
- A step in a process.
- A sentence from a lesson.

The important thing is that one bit should not be a whole page of notes. Smaller chunks are easier to practise and easier to repeat.

## Prompt and Answer Practice

This is the basic card idea.

The app shows a title, question, or cue first. The user tries to answer without seeing the answer. Then they can reveal it or smart-check their response.

Example:

Prompt: What is photosynthesis?

Answer: The process plants use to turn light, water, and carbon dioxide into food.

This is useful because it makes the brain retrieve the answer instead of just rereading it.

In the app, exact prompt-answer material can now be entered with separate question and answer boxes. This is easier than forcing every card into one pasted field.

## Spaced Review

Spaced review means revisiting information after some time has passed.

If something was hard, it comes back sooner. If it was easy, it can wait longer.

This helps because memory gets stronger when it is recalled right before it would have started fading.

## Focus Queue

The focus queue is the app's daily study plan.

It brings together cards that are due, cards that were weak before, and fresh cards that have not been practised much yet.

This is closer to how common study apps guide users, because the user does not have to decide where to begin every time.

## Smart Check

Smart Check compares what the user wrote with the expected answer.

It does not need the wording to be exact. It looks for whether the important ideas are close enough.

This is useful for learners because a correct answer might be written in different words.

## Repetition Path

The repetition path is for practising a group of study bits in a controlled order.

The current rule is:

If the user starts at item 5 with range 3, the app practises:

5

5-4

5-4-3

Then it walks back to the first item:

3-2-1

This helps the user revise older material while still focusing on the newer item.

## Quick Quiz

Quick Quiz can work in two ways.

Self Check:

The user sees the question, answers it themselves, then reveals or smart-checks the answer.

Multiple Choice:

The user picks from answer choices.

Self Check is better for real recall. Multiple choice is useful when the user wants something faster or easier.

## Associations

Associations help connect hard information to something easier to remember.

Examples:

- Acronyms.
- Mini stories.
- Routes.
- Images.
- Silly or unusual links.

The point is not to make the memory perfect. The point is to give the brain a hook.

## Sequence Recall

Sequence recall is for remembering things in order.

The app briefly shows a sequence, hides it, and asks the user to reproduce it.

This can help with numbers, steps, routines, or ordered lists.

## Word Recall

Word recall shows a small group of words for a short time.

The user then tries to say or type them back.

This is simple, but good for attention and short-term memory practice.

## Media Cues

MemoryPal can attach image, audio, and video cues.

These can help when text alone is not enough.

Examples:

- A picture of a place.
- A voice reminder.
- A short explanation video.
- A photo of an object.

For elderly users, familiar images and voices can be especially helpful.

## Chunking

Chunking means grouping information into smaller meaningful pieces.

Instead of studying one long note, the user studies several smaller chunks.

MemoryPal now uses this idea directly through study bits.

## Memory Palace

This is not fully built yet, but it is a good future idea.

The user imagines a familiar place and puts each memory item in a location.

Example:

Front door: first item.

Kitchen: second item.

Bedroom: third item.

Then they mentally walk through the place to remember the list.

## Error Practice

The app should pay attention to weak items.

If the user keeps missing the same card or chunk, that item should come back more often.

This is useful because the app should not waste time equally on everything.

## Caregiver-Friendly Memory

For elderly users, another person might help create the study bits.

Good caregiver prompts are simple and practical:

- Who is this person?
- What is this appointment?
- Where is this item kept?
- What should happen next?

These should be calm and respectful, not overwhelming.

## Short Summary

MemoryPal combines:

- Small study bits.
- A focus queue for due, weak, and fresh cards.
- Prompt and answer practice.
- Spaced review.
- Smart checking.
- Repetition paths.
- Associations.
- Simple recall games.
- Media cues.

The main design goal is to make memory practice feel clear, gentle, and useful.
