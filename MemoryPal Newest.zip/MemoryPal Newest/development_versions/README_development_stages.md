# MemoryPal Development Versions

This folder contains standalone milestone versions of MemoryPal. Each `MemoryPal_vXX_*.py` file is an independent Python/Tkinter program and can be copied or run by itself.

The versions are reconstructed from the request history in this project. They are not exact saved snapshots from the past, because the earlier states were not preserved as separate files, but each file now behaves like the feature request it represents.

## Current Full App

The current full recovered app is:

`../latest_app/MemoryPalDesktop.py`

It includes DPI-aware scaling, chunk-based capture, prompt-answer modes, smart checking, repetition paths, text/image/audio/video file imports, and on-demand text/audio/video capture controls.

## How to Run a Version

Open a terminal in this folder and run:

```powershell
python MemoryPal_v14_test_walkback_repetition.py
```

If `python` is not on PATH, use the Python interpreter installed on the PC and pass it the file path.

## Version History

### v01 Alpha - Initial runnable PC app

- Created the first runnable desktop app.
- Established the memory trainer idea with capture, review, quiz, associations, puzzles, and library areas.

### v02 Alpha - Scaled UI resolution

- Increased the window and control sizes.
- Added DPI-aware setup so the UI looks sharper on scaled Windows displays.

### v03 Alpha - Multiple study bits and newline parsing

- Added parsing for `/n`, real newlines, numbering, and separators.
- Made revision work with several small bits of information instead of one long text field.

### v04 Alpha - Media support beyond flashcards

- Added image and audio import controls to the capture flow.
- Media cues became part of the study material rather than flashcard-only extras.

### v05 Beta - First modern UI pass

- Replaced the plain form feeling with modern dashboard cards.
- Improved color, spacing, and large action buttons.

### v06 Beta - Removed decorative animation

- Removed the distracting decorative animation.
- Kept the interface calm and predictable for learners and elderly users.

### v07 Beta - Structured non-random revision path

- Changed shuffle from random order into an intentional revision path.
- The prototype previews the order before the user starts.

### v08 Beta - Notesheet and design artifacts

- Added a human-readable memory techniques notesheet.
- Added design/development documentation alongside the code.

### v09 Test - Home button scaling fixes

- Fixed dashboard button scaling and clipping.
- The prototype uses equal-width action cards to behave better in smaller windows.

### v10 Test - Start/range repetition and smart checking

- Added start/range repetition controls.
- Added close-enough Smart Check scoring with suggested repetitions.

### v11 Test - Text, image, audio, and video support

- Added text, image, audio, and video import concepts.
- Media cues are shared by the study item rather than locked to one mode.

### v12 Test - Chunk-based capture and card creation

- Changed capture into a study-set builder.
- Each chunk can become its own card.

### v13 Test - Scrollable practice and capture screens

- Added scrollable long forms.
- Buttons remain reachable when the window is smaller.

### v14 Test - Final walk-back repetition rule

- Implemented the clarified pattern: start `5`, range `3` gives `5`, `5-4`, `5-4-3`, then `3-2-1`.
- The version focuses on the exact repetition behavior requested.

### v15 Beta - Modernized dashboard and shell

- Polished the app shell and dashboard cards.
- Improved hierarchy so the interface feels more like a deliberate app.

### v16 Test - Prompt-answer practice modes

- Added question/title prompt-first practice.
- Users can reveal or Smart Check without a fixed number of repetition rounds.

### v17 Test - Imported and on-demand text/audio/video inputs

- Added file-import and on-demand capture controls for text, audio, and video.
- The desktop prototype supports text-note recording directly and prepares audio/video recording for optional desktop dependencies and a future mobile build.

### v18 Beta - Study-app polish pass

- Added a Focus queue for due, weak, and fresh cards.
- Improved the dashboard, direct Q/A card creation, and library search/filtering to better match what users expect from a study app.

### v19 Beta - Interaction and capture polish

- Added separate question and answer boxes for exact prompt-answer card creation.
- Improved answer input panels and added a subtle section transition animation.

### v20 Beta - Review testing and Q/A polish

- Added optional saved answers for question cards and a separate Test Lab page.
- Smart Check now visually highlights the selected bucket, and mini-story generation creates ordered memory scenes.

### v21 Test - Pointer-aware page scrolling

- Improved scrolling so the mouse wheel works over the active page section instead of requiring the scrollbar area.
- Nested scroll areas now scroll the section under the pointer.

### v22 Beta - Test Lab review flow

- Review now launches cards into Test Lab instead of doing answer/reveal inline.
- Test Lab can complete review scheduling, and self-check quiz cards can open there too.

## Mobile Version Note

A separate mobile version is still needed later. It should use native phone APIs for the microphone, camera, file picker, storage permissions, and large touch controls instead of trying to copy the desktop Tkinter interface directly.
